var noise = null;

var NoiseMeter = {
    getNoise: function(successCallback, errorCallback, options) {

        cordova.exec(function(n) {
            noise = n
        }, function(error) {
            errorCallback(error);
        }, "NoiseMeter", "start", []);
        
        setInterval(function(){
            if(noise)
                successCallback(noise);
        },100);

        if(noise)
            successCallback(noise);

    }
}

module.exports = NoiseMeter;