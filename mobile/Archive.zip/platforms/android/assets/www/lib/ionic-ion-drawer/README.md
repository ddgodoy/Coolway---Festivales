ionic-contrib-drawer
====================

A side menu drawer for Ionic apps
