package com.mpcode.cordova.noisemeter;

import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;

import android.os.Handler;
import android.os.Looper;

import android.media.MediaRecorder;
import java.io.IOException;

public class NoiseMeter extends CordovaPlugin {

  private CallbackContext cContext;
  private boolean running = false;
  private int noise = 0;
  private MediaRecorder mRecorder = null;

  /**
  * Sets the context of the Command. This can then be used to do things like
  * get file paths associated with the Activity.
  *
  * @param cordova The context of the main Activity.
  * @param webView The associated CordovaWebView.
  */
  @Override
  
  public void initialize(CordovaInterface cordova, CordovaWebView webView) {
    super.initialize(cordova, webView);
  }

  /**
  * Executes the request.
  *
  * @param action        The action to execute.
  * @param args          The exec() arguments.
  * @param callbackId    The callback id used when calling back into JavaScript.
  * @return              Whether the action was valid.
  */
  public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
    if (action.equals("start")) {
      this.running = true;
      this.cContext = callbackContext;

      if(mRecorder == null )
      {
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mRecorder.setOutputFile("/dev/null"); 

        try {
            mRecorder.prepare();
        } catch (IOException e) {
            return false;
        }

        mRecorder.start();
      }
      
      cordova.getThreadPool().execute(new Runnable() {
        public void run() {
          while(running)
          {
            noise = mRecorder.getMaxAmplitude();
            win();
            try{Thread.sleep(200);}catch(InterruptedException ie){ie.printStackTrace();}
          }
        }
      });
    }    
    return true;
  }

  private void win() {
    // Success return object
    PluginResult result = new PluginResult(PluginResult.Status.OK, Integer.toString(noise) );
    result.setKeepCallback(true);
    cContext.sendPluginResult(result);
  }

  private void stop() {
    if (this.running) {
        this.running = false;
        this.mRecorder.stop();
        this.mRecorder.release();
        this.mRecorder = null;
    }
  }

  @Override
  public void onReset() {
    if (this.running) {
      this.stop();
    }
  }

  public void onDestroy() {
    this.stop();
  }

}